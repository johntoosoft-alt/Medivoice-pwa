# MediVoice — App Deployment Guide
## PWA + Google Play Store

---

## PART 1: HOST YOUR PWA (Do This First)

Your app needs to be hosted online before it can be installed or submitted to Play Store.

### Option A: Netlify (FREE — Recommended)
1. Go to https://netlify.com → Sign up free
2. Drag and drop your entire `medivoice-pwa` folder onto the Netlify dashboard
3. Netlify gives you a URL like: `https://medivoice-abc123.netlify.app`
4. DONE — your app is live and installable in 2 minutes

### Option B: GitHub Pages (FREE)
1. Go to https://github.com → Create account → New repository named `medivoice`
2. Upload all files in the `medivoice-pwa` folder
3. Go to Settings → Pages → Select main branch → Save
4. Your URL: `https://yourusername.github.io/medivoice`

### Option C: Your Own Domain
- Point your domain to the hosting above
- Example: `https://medivoice.ng` or `https://app.yourhospital.com`
- Must have HTTPS (SSL) — Netlify provides this free

---

## PART 2: HOW PATIENTS INSTALL THE APP

Once hosted, patients install like this:

### Android (Chrome):
1. Visit your URL in Chrome
2. Tap the banner at bottom: "Install MediVoice" → tap Install
3. OR tap ⋮ menu → "Add to Home screen"
4. App appears on home screen with your icon

### iPhone (Safari):
1. Visit your URL in Safari (must be Safari, not Chrome)
2. Tap the Share button (box with arrow)
3. Scroll down → "Add to Home Screen"
4. Tap Add → App appears on home screen

### Staff can also do the same to have the dashboard on their phones!

---

## PART 3: GOOGLE PLAY STORE (TWA Method)

This puts MediVoice on the Play Store as a real Android app using Google's official PWA wrapper (Trusted Web Activity). No coding needed.

### Requirements:
- Your PWA must be hosted with HTTPS ✓
- Google Developer Account ($25 one-time fee)
- A `assetlinks.json` file on your server

### Steps:

**Step 1 — Create Google Developer Account**
- Go to https://play.google.com/console
- Pay $25 one-time registration fee
- Fill in developer profile

**Step 2 — Use PWA Builder (Microsoft's free tool)**
- Go to https://www.pwabuilder.com
- Enter your hosted URL (e.g. https://medivoice-abc123.netlify.app)
- Click "Package for stores" → Select "Google Play"
- Download the Android package (.aab file)
- This tool handles everything automatically — no Android Studio needed

**Step 3 — Upload to Play Console**
- Go to https://play.google.com/console
- Create new app → "MediVoice"
- Upload your .aab file from Step 2
- Fill in: description, screenshots, category (Medical)
- Submit for review (takes 3-7 days)

**Step 4 — Add assetlinks.json**
PWA Builder will give you a file called `assetlinks.json`
Upload it to your server at this exact path:
`https://yourdomain.com/.well-known/assetlinks.json`
On Netlify: just put the file in a folder called `.well-known`

---

## PART 4: MULTI-HOSPITAL (SAAS) SETUP

When you are ready to sell MediVoice to multiple hospitals:

### Each Hospital Gets:
- Their own subdomain: `hospital-name.medivoice.ng`
- Their own login credentials
- Their own patient data (separate databases)
- Custom hospital name/logo in the app

### How to Set This Up:
1. Buy a domain: `medivoice.ng` (~$15/year from Namecheap)
2. Use Netlify or Vercel for hosting
3. Each hospital = a new deployment with their config
4. Add Firebase for real-time data sync between staff phones and TV screens

### Pricing Suggestion:
- ₦50,000/month per hospital (~$35 USD)
- 10 hospitals = ₦500,000/month
- 50 hospitals = ₦2,500,000/month

---

## FILE STRUCTURE (what's in your zip)

```
medivoice-pwa/
├── index.html          ← The entire app (patient + staff)
├── manifest.json       ← Makes it installable as an app
├── service-worker.js   ← Offline support
├── icons/
│   ├── icon-72.png
│   ├── icon-96.png
│   ├── icon-128.png
│   ├── icon-144.png
│   ├── icon-152.png
│   ├── icon-192.png    ← Used on home screen
│   ├── icon-384.png
│   └── icon-512.png    ← Used on Play Store
└── DEPLOYMENT_GUIDE.md ← This file
```

---

## NEXT STEPS CHECKLIST

- [ ] Host on Netlify (15 minutes)
- [ ] Test install on your Android phone
- [ ] Share URL with your hospital for testing
- [ ] Set up Firebase for real-time data sync
- [ ] Create Google Developer Account ($25)
- [ ] Submit to Play Store via PWA Builder
- [ ] Register domain medivoice.ng
- [ ] Onboard first paying hospital

---

Built with MediVoice AI System
Support: contact your developer
